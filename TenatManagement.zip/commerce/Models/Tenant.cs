﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace commerce.Models
{
    public class TenantModel : BaseEntity
    {
        [Required(ErrorMessage = "First name is required.")]
        public string? name { get; set; }

        [Required(ErrorMessage = "price is required")]
        public double price { get; set; }

        [Required(ErrorMessage = "phone no is required")]
        public string? phone { get; set; }
    }
}
