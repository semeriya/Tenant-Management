﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace commerce.Models
{
    public class TenantDbHandle
    {
        private SqlConnection con;
        private readonly IConfiguration _configuration;

        public TenantDbHandle(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private void connection()
        {
            //var constring = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var constring = _configuration["ConnectionStrings:DefaultConnection"];
            con = new SqlConnection(constring);
        }

        public bool AddTenant(TenantModel tmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("sp_InsertTenant", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@name", tmodel.name);
            cmd.Parameters.AddWithValue("@price", tmodel.price);
            cmd.Parameters.AddWithValue("@phone", tmodel.phone);

            //con.Open();
            //int newTenantId = Convert.ToInt32(cmd.ExecuteScalar());
            //con.Close();

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;

            //return newTenantId;
        }

        public List<TenantModel> GetTenants()
        {
            connection();
            List<TenantModel> Tenantlist = new List<TenantModel>();

            SqlCommand cmd = new SqlCommand("sp_GetTenants", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                Tenantlist.Add(
                    new TenantModel
                    {
                        Tid = Convert.ToInt32(dr["Tid"]),
                        name = Convert.ToString(dr["name"]),
                        price = Convert.ToDouble(dr["price"]),
                        phone = Convert.ToString(dr["phone"]),
                        CreatedAt = Convert.ToDateTime(dr["CreatedAt"]),
                        UpdatedAt = Convert.ToDateTime(dr["UpdatedAt"])
                    });
            }
            return Tenantlist;
        }

        public bool UpdateTenant(TenantModel tmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("sp_UpdateTenant", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Tid", tmodel.Tid);
            cmd.Parameters.AddWithValue("@name", tmodel.name);
            cmd.Parameters.AddWithValue("@price", tmodel.price);
            cmd.Parameters.AddWithValue("@phone", tmodel.phone);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        public bool DeleteTenant(int id)
        {
            connection();
            SqlCommand cmd = new SqlCommand("sp_DeleteTenant", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Tid", id);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        public TenantModel GetTenantById(int id)
        {
            connection();
            TenantModel tenant = new TenantModel();

            SqlCommand cmd = new SqlCommand("sp_GetTenantById", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Tid", id);

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                reader.Read();
                tenant.Tid = Convert.ToInt32(reader["Tid"]);
                tenant.name = Convert.ToString(reader["name"]);
                tenant.price = Convert.ToDouble(reader["price"]);
                tenant.phone = Convert.ToString(reader["phone"]);
                tenant.CreatedAt = Convert.ToDateTime(reader["CreatedAt"]);
                tenant.UpdatedAt = Convert.ToDateTime(reader["UpdatedAt"]);
            }

            reader.Close();
            con.Close();

            return tenant;
        }
    }
}
