﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using commerce;
using commerce.Models;

namespace commerce.Controllers
{
    public class TenantModelsController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly TenantDbHandle dbhandle;

        public TenantModelsController(IConfiguration configuration)
        {
            _configuration = configuration;
            dbhandle = new(_configuration);
        }

        // GET: TenantModels
        public IActionResult Index()
        {
            return dbhandle.GetTenants() != null ?
                        View(dbhandle.GetTenants()) :
                        Problem("Entity set 'Tenant.Tenants'  is null.");
        }

        // GET: TenantModels/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tenantModel = dbhandle.GetTenantById(id.Value);
            if (tenantModel == null)
            {
                return NotFound();
            }

            return View(tenantModel);
        }

        // GET: TenantModels/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TenantModels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("name,price,phone,Tid,CreatedAt,UpdatedAt")] TenantModel tenantModel)
        {
            if (ModelState.IsValid)
            {
                dbhandle.AddTenant(tenantModel);
                return RedirectToAction(nameof(Index));
            }
            return View(tenantModel);
        }

        // GET: TenantModels/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tenantModel = dbhandle.GetTenantById(id.Value);
            if (tenantModel == null)
            {
                return NotFound();
            }
            return View(tenantModel);
        }

        // POST: TenantModels/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("name,price,phone,Tid,CreatedAt,UpdatedAt")] TenantModel tenantModel)
        {
            if (id != tenantModel.Tid)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    dbhandle.UpdateTenant(tenantModel);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TenantModelExists(tenantModel.Tid))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tenantModel);
        }

        // GET: TenantModels/Delete/5
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tenantModel = dbhandle.GetTenantById(id.Value);
            if (tenantModel == null)
            {
                return NotFound();
            }

            return View(tenantModel);
        }

        // POST: TenantModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var tenantModel = dbhandle.GetTenantById(id);
            if (tenantModel != null)
            {
                dbhandle.DeleteTenant(id);
            }

            return RedirectToAction(nameof(Index));
        }

        private bool TenantModelExists(int id)
        {
            return (dbhandle.GetTenants()?.Any(e => e.Tid == id)).GetValueOrDefault();
        }
    }
}
