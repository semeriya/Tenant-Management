﻿using commerce.Models;
using Microsoft.EntityFrameworkCore;

namespace commerce;

public class Tenant : DbContext
{
    public Tenant(DbContextOptions<Tenant> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
    }

    public DbSet<TenantModel> Tenants { get; set; } = default!;
}
